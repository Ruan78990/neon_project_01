from django.contrib import admin
from django.urls import path, include
from core.views import home, pagina_teste

urlpatterns = [
path('admin/', admin.site.urls),
path('accounts/', include('django.contrib.auth.urls')),
path('teste/', pagina_teste, name='url_teste'),
path('', home),]