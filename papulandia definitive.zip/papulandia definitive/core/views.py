from django.shortcuts import render, redirect
def home(request):

    if not request.user.is_authenticated:
        return render(request, 'core/ index.html')

    if request.user.is_superuser:
        return redirect('/admin/')

    return render(request, 'core/aluno_home.html')


def pagina_teste(request):
    return render(request,'core/teste.html')